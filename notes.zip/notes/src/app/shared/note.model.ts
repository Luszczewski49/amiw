export class Note {
    public title: string;
    public body: string;
}